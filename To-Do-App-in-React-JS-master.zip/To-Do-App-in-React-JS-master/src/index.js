import './index.css'

import ReactDOM  from 'react-dom/client'
import App from './App';

let Root=ReactDOM.createRoot(document.getElementById('root'));

Root.render(
        <App/>
)